
clc; clear; close all;


%% User Input Parameters
F = input('Enter the applied force (N): ');
b = input('Enter the contact width (m): ');
v = input('Enter Poissons ratio: ');
E = input('Enter Youngs Modulus (Pa): ');

% Gear Parameters
m = input('Enter the module (mm): ');
z1 = input('Enter the number of teeth of the gear: ');
z2 = input('Enter the number of teeth of the pinion: ');
x1 = input('Enter the profile shift coefficient of the gear: ');
x2 = input('Enter the profile shift coefficient of the pinion: ');
p = input('Enter the pressure angle (degrees): ');
epsilon = input('Enter the contact ratio: ');

%drawing the gear
call_gear = gear(gearRack(m),z1);
print(call_gear)
plot(call_gear,'-nz',1)
plot(call_gear,'gen')



%%calulcations of gear geometry based on input parameters

%pressure  conversion
alpha_0 = deg2rad(p);          % Pressure angle in radians
inv_alpha_0 = tan(alpha_0) - alpha_0; % Involute of alpha

% Basic Parameters
cp = pi * m; %circular pitch
rp = (m * z1) / 2/1000; % Pitch circle radius
rb = rp * cosd(p); % Base circle radius
ra = rp + (m/1000); % Addendum circle radius
rr = rp - (1.25 * m/1000); % Root circle radius (typically pitch radius - 1.25 module)
ru = rb*sqrt(1+tan(alpha_0)); %distance from the center to the point of contact                                                                                                                                                                                                                                                                             


% Radius of curvature (m)
rho1 = rb .* tan(alpha_0);
rho2 = rho1;

%% Intermediate Parameters and Calculations
theta_b = (2 ./ z1) .* (pi ./ 2 + 2 .* tan(alpha_0)) + 2 .* inv_alpha_0;
alpha_u = acos(rb ./ ru);
k1 = rp .* cos(alpha_0) .* (tan(alpha_u) - tan(tan(alpha_u) - theta_b ./ 2));
k2 = k1;

% Parameter 'a' for contact deformation calculation
a = sqrt((8 .* F .* rho1 .* rho2 .* (1 - v^2)) ./ (b .* pi .* E .* (rho1 + rho2)));

%% Contact Deformation (delta_c)
delta_c = (4 .* F ./ (b .* pi .* E)) .* ((1 - v^2) .* log((2 .* sqrt(k1 .* k2)) ./ a) - v ./ (2 .* (1 - v)));

% Find maximum deflection and corresponding force
[max_deflection, idx] = max(delta_c);
max_force = F(idx);

% Display maximum deflection result
fprintf('tooth Deflection (delta_c): %.6e m\n', delta_c);




%Bending Deflection Calculation
% Define constants
rf = rr;           % Root radius (m)
k = k1;            % Offset constant (m)
d_y = linspace(call_gear.sd/1000, call_gear.sr/1000, 1000);  % Distance array (in meters)

% Compute uw
uw = rp - rf;  % Distance (m)
limit=linspace(0,uw,1000);

% First term integration (term1_integrand)
term1_integrand = ((uw - d_y).^2) ./ (d_y.^3);
term1_integral = trapz(limit, term1_integrand);  % Use trapz for numerical integration

% Second term integration (term2_integrand)
term2_integrand = 1 ./ d_y;
term2_integral = trapz(limit, term2_integrand);  % Use trapz for numerical integration

% Final Bending Deflection Formula
delta_b = (F * cos(alpha_u)^2 / (b * E)) * ...
    (10.92 * term1_integral + 3.1 * (1 + 0.294 * tan(alpha_u)^2) * term2_integral);

%% Display Results for Gear Dimensions, Deflections, and Forces
fprintf('Bending Deflection (delta_b): %.6e m\n', delta_b);






%gear body contribution deflection calculation
sf_w = call_gear.sd/1000;  
theta_f = atan(call_gear.sd/(2*rb*1000));
h=4.2;           

% Calculate deflection from gear body contribution
deflection_fw = gear_body_contribution(E, F, b, alpha_u, h, theta_f, uw, sf_w);

% Display result for gear body contribution deflection
fprintf('Gear body contribution deflection (fw): %.6e m\n', deflection_fw);


T = delta_b + deflection_fw  + delta_c;

% Display the result
fprintf('Total deflection T: %.6e m\n', T);

% Define constants (example values, replace with actual values as needed)
C1 = 0.04723; C2 = 0.15551; C3 = 0.25791; C4 = 0.00635;
C5 = 0.11654; C6 = 0.00193; C7 = 0.24188; C8 = 0.00529; C9 = 0.00182;

% Define input parameters (example values)
terms = 10;     % Number of Fourier series terms
facewidth=b*10^3;

% Compute stiffness c in N/mm^2
c_prime_inverse = C1 + (C2/z1) + (C3/z2) - (C4*x1) - (C5*(x1/z1)) - (C6*x2) - (C7*(x2/z2)) + (C8*x1^2) + (C9*x2^2);
c_prime = (1/c_prime_inverse) * facewidth * 1e6;  % Convert to N/m
c_gamma = c_prime * (0.75 * epsilon + 0.25);  % Double pair stiffness in N/m

% Define dimensionless time array
tau = linspace(0, 2 * pi, 500);

% Compute mesh stiffness
stiffness_values = c_prime + (c_gamma - c_prime) * (epsilon - m);
for n = 1:terms
    stiffness_values = stiffness_values + (2 * (c_gamma - c_prime) / (pi * n)) * ...
        sin(pi * n * (epsilon - m)) .* cos(n * tau);
end

% Plot the results
figure;
plot(tau, stiffness_values, 'b', 'LineWidth', 1.5);
xlabel('Dimensionless Time (\tau)');
ylabel('Mesh Stiffness (N/m)');
title('Total Stiffness of Spur Gearing');
grid on;
legend('Total Mesh Stiffness');


a = gearRack(m); 
g1 = gear(a,z1,'-x',0.352); 
print(g1) 
plot(g1,'-nz',4) 
g2 = gear(a,z2,'-x',0.3); 
print(g2); 
plot(g2,'-nz',4) 
gm = gearsInMesh(g1,g2); 
plot(gm) 
plot(gm,'-zoom',6,'-th1',30) 
animate(gm,'-zoom',6,'-dth1',1,'-nr',0.3,'save')
print(gm)

function deflection_fw = gear_body_contribution(E, F, b, alpha_u, h, theta_f, uw, Sf_w)
    % Coefficients for polynomial curve fitting (replace with actual values)
    A1 = -5.574e-5; B1 = -1.9986E-3; C1 = -2.3015E-4; D1 = 4.7702e-3; E1 = 0.0271; F1 = 6.8045;
    A2 = 60.111e-5; B2 = 28.100E-3; C2 = -83.431e-4;D2 = -9.9256e-3; E2 = 0.1624; F2 = 0.9086;
    A3 = -50.952e-5; B3 = 185.50E-3; C3 = 0.0538e-4; D3 = 53.300e-3; E3 = 0.2895; F3 = 0.9236;
    A4 = 6.2042e-5; B4 =  9.0889E-3; C4 = -4.0964e-4; D4 = 7.8297e-3; E4 = -0.1472; F4 = 0.6904;

    % Polynomial functions for L*(h, theta_f), M*(h, theta_f), P*(h, theta_f), Q*(h, theta_f)
    L_star = @(h, theta_f) A1 / theta_f^2 + B1 * h^2 + C1 / theta_f + D1 / theta_f + E1 * h + F1;
    M_star = @(h, theta_f) A2 / theta_f^2 + B2 * h^2 + C2 / theta_f + D2 / theta_f + E2 * h + F2;
    P_star = @(h, theta_f) A3 / theta_f^2 + B3 * h^2 + C3 / theta_f + D3 / theta_f + E3 * h + F3;
    Q_star = @(h, theta_f) A4 / theta_f^2 + B4 * h^2 + C4 / theta_f + D4 / theta_f + E4 * h + F4;

    % Calculating components
    L_h_theta_f = L_star(h, theta_f);
    M_h_theta_f = M_star(h, theta_f);
    P_h_theta_f = P_star(h, theta_f);
    Q_h_theta_f = Q_star(h, theta_f);

    % Calculation of the gear body contribution deflection (fw)
    deflection_fw = (1 / E) * (2 * F / b * cosd(alpha_u)^2) * ...
        (L_h_theta_f * (uw / Sf_w) + M_h_theta_f * (uw / Sf_w) + P_h_theta_f * (1 + Q_h_theta_f * tan(alpha_u)^2));
end




