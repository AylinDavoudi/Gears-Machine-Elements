# Gear Simulator

This folder contains two versions of the Gear Simulator:
- A Live Script (.mlx) for an interactive and visually enhanced experience.
- A Regular Script (.m) for standard execution.

## Features
The Gear Simulator performs the following functions:
- Calculates essential gear parameters and deflections.
- Computes and plots non-dimensional, time-varying mesh stiffness.
- Generates detailed graphs and animations related to Areas of Engagement (AoE) in gear dynamics.

## Setup Instructions
Before running the simulator, follow these steps:
1. Add the entire folder and all subfolders to MATLAB's path to ensure all dependencies are accessible.
2. Include the `draw2d` file in the MATLAB path, as it is required for graphical rendering.

Ensure these steps are completed before execution for optimal performance.

