function drawSet(varargin)
%DRAWSET Wrapper to gkSet
    narginchk(0,inf)
    nargoutchk(0,0) 
    gkSet(varargin{:});   
end

