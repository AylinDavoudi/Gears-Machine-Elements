function gkClose
%GKCLOSE destroy gdata table
    global gkdata
    clear global gkdata
end