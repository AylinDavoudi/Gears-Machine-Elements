function drawShow
%DRAWSHOW Wrapper to MATLAB shg
%
%History:
%   2019,May   - MB created
%
    shg
end

