function [x,y] = swap(x,y)
    t = x;
    x = y;
    y = t;
end

